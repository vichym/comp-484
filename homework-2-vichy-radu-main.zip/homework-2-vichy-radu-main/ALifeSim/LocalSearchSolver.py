"""  =================================================================
File: SearchSolver.py

This file contains generic definitions for a state space SearchState class,
and a general SearchSolver class.  These classes should be subclassed to make
solvers for a specific problem.
 ==================================================================="""

import random
import math

# Change this to true to see information about the search as it goes.
verbose = True


class RulesetState(object):
    """
    This represents a "state" for the local search. Essentially, this packages up a particular rule string with some
    methods to generate neighbor states, and the functionality to call an evaluation function and pass the rule string
    to it to determine the value of a string.
    """

    RULE_LEN = 27

    def __init__(self, evalFunction, maxValue, ruleString=None):
        """Initialize the two basic instance variables to some value"""
        self.evalFunction = evalFunction
        self.maxValue = maxValue
        self.stateValue = None
        if ruleString is not None:
            self.ruleString = ruleString
        else:
            self.ruleString = self._randomRuleset()

    def getEvalFunction(self):
        return self.evalFunction

    def getMaxValue(self):
        return self.maxValue

    def getValue(self):
        """Access the value of the myCost instance variable"""
        if self.stateValue is None:
            self.stateValue = self.evalFunction(self.ruleString)
        return self.stateValue

    def getMaxValue(self):
        """Return the maximum value this state has been reported to have."""
        return self.maxValue

    def allNeighbors(self):
        """Generates all neighbors of this state. For the ruleset, that means all one-symbol changes."""
        neighbors = []
        for i in range(len(self.ruleString)):
            currSym = self.ruleString[i]
            otherSyms = self._otherSymbols(currSym)
            for c in otherSyms:
                newRule = self.ruleString[:i] + c + self.ruleString[i + 1:]
                newState = RulesetState(self.evalFunction, self.maxValue, newRule)
                neighbors.append(newState)
        return neighbors

    def stochasticNeighbors(self):
        """Generates some random neighbors of this state."""
        neighbors = []
        for i in range(len(self.ruleString)):
            currSym = self.ruleString[i]
            otherSyms = self._otherSymbols(currSym)
            for c in otherSyms:
                newRule = self.ruleString[:i] + c + self.ruleString[i + 1:]
                newState = RulesetState(self.evalFunction, self.maxValue, newRule)
                neighbors.append(newState)
        return random.sample(neighbors, 8)

    def _otherSymbols(self, sym):
        """Given a symbol, return a string of the other symbols besides it."""
        if sym == 'a':
            return 'sflr'
        elif sym == 's':
            return 'aflr'
        elif sym == 'f':
            return 'aslr'
        elif sym == 'l':
            return 'asfr'
        elif sym == 'r':
            return 'asfl'
        else:
            print("_otherSymbols: should never get here!")

    def randomNeighbors(self, num):
        """Generate num random neighbors of this state. Note that the same neighbor could be generated more than once."""
        neighbors = []
        for i in range(num):
            newS = self.makeRandomMove()
            neighbors.append(newS)
        return neighbors

    def makeRandomMove(self):
        """Takes a ruleset and returns a new ruleset identical to the original, but with one random change."""
        randElem = random.randrange(len(self.ruleString))
        opts = self._otherSymbols(self.ruleString[randElem])
        newElem = random.choice(opts)
        newRules = self.ruleString[:randElem] + newElem + self.ruleString[randElem + 1:]
        return RulesetState(self.evalFunction, self.maxValue, newRules)

    def getRandomStates(self, n):
        """Builds n random states that use the same eval function and max value but are
        unrelated to this state."""
        newStates = []
        for i in range(n):
            newRule = self._randomRuleset()
            newState = RulesetState(self.evalFunction, self.maxValue, newRule)
            newStates.append(newState)
        return newStates

    def _randomRuleset(self):
        """Generate a random ruleset string"""
        options = "sflr"  # Leaving out the "arbitrary" random behavior
        rules = ""
        for i in range(self.RULE_LEN):
            rules += random.choice(options)
        return rules

    def copyState(self):
        return RulesetState(self.evalFunction, self.maxValue, self.ruleString)

    def __str__(self):
        """Make a string representation of this state, for printing"""
        return self.ruleString


# ==================================================================
# This section contains an implementation of straightforward
# Hill Climbing. It requires a state class that creates objects
# that implement the following methods: getValue, getMaxValue,
# allNeighbors, randomNeighbors, and that are printable

class HillClimber(object):
    """Contains the algorithm for hill-climbing and some helper methods."""

    def __init__(self, startState, maxRounds=500):
        """Sets up the starting state"""
        self.startState = startState
        self.maxRounds = maxRounds
        self.maxValue = startState.getMaxValue()
        self.currState = startState
        # This next step is EXPENSIVE!
        self.currValue = self.currState.getValue()
        self.count = 0
        if verbose:
            print("============= START ==============")

    def getCount(self):
        """Returns the current count."""
        return self.count

    def getCurrState(self):
        """Returns the current state."""
        return self.currState

    def getCurrValue(self):
        """Returns the value currently associated with the current state."""
        return self.currValue

    def run(self):
        """Perform the hill-climbing algorithm, starting with the given start state and going until a local maxima is
        found or the maximum rounds is reached"""
        status = None

        while self.currValue < self.maxValue and self.count < self.maxRounds:  # while the currentValue is smaller than maxValue
            status = self.step()
            if status == 'optimal' or status == 'local maxima':
                break

        if verbose:
            print("============== FINAL STATE ==============")
            print(self.currState)
            print("   Number of steps =", self.count)
            if status == 'optimal':
                print("  FOUND PERFECT SOLUTION")
        return self.currValue, self.maxValue, self.count

    def step(self):
        """Runs one step of hill-climbing, generates children and picks the best one, returning it as its value. Also returns
        a second value that tells if the best child is optimal or not."""
        self.count += 1
        if verbose:
            print("--------- Count =", self.count, "---------")
            print(self.currState)
        neighs = self.currState.stochasticNeighbors()  # TODO(DONE): Modify the number of neighbors here
        bestNeigh = self.findBestNeighbor(neighs)
        nextValue = bestNeigh.getValue()
        self.currState = bestNeigh
        self.currValue = nextValue
        if nextValue == self.maxValue:
            return 'optimal'
        if nextValue >= self.currValue:
            if verbose:
                print("Best neighbor:")
                print(bestNeigh)
            return 'keep going'
        else:
            # best is worse than current
            return 'local maxima'

    def findBestNeighbor(self, neighbors):
        """Given a list of neighbors and values, find and return a neighbor with
        the best value. If there are multiple neighbors with the same best value,
        a random one is chosen"""
        startBest = neighbors[0]
        print(startBest.ruleString)
        bestValue = startBest.getValue()
        bestNeighs = [startBest]
        for neigh in neighbors[1:]:
            value = neigh.getValue()
            if value > bestValue:
                bestNeighs = [neigh]
                bestValue = value
            elif value == bestValue:
                bestNeighs.append(neigh)
        bestNeigh = random.choice(bestNeighs)
        return bestNeigh


# TODO (DONE): Implement the Genetic Algorithm searcher modeled on the HillClimber above

class GASearcher(object):
    """Contains the genetic algorithm some helper methods."""
    def __init__(self, startState, maxRounds=500, popSize=10, maxGenerations=20, crossPerc=0.8, mutePerc=0.01):
        """Sets up the starting state"""
        self.startState = startState
        self.maxRounds = maxRounds
        self.maxValue = startState.getMaxValue()
        self.bestSoFarState = startState
        self.count = 0

        #  From Advisor
        self.popSize = popSize + 1 if popSize % 2 == 1 else popSize # if user puts in an odd population size, make it even
        self.maxGenerations = maxGenerations
        self.crossPerc = crossPerc
        self.mutePerc = mutePerc

        # Generate Generation 0 of RulesetState
        self.currStates = self.startState.getRandomStates(self.popSize)
        self.maxFit = self.currStates[0].getMaxValue()
        self.bestSoFarValue = self.bestSoFarState.getValue()

        if verbose:
            print("============= START ==============")
            print("Best of Genaration:{} \t {} \tScore {}".format(self.count, self.bestSoFarState, self.bestSoFarValue))

    def getCount(self):
        """Returns the current count."""
        return self.count

    def getCurrState(self):
        """Returns the current best state."""
        return self.bestSoFarState

    def getCurrValue(self):
        """Returns the value currently associated with the current best state."""
        return self.bestSoFarValue

    def step(self):
        """One step is one generation search and returns the best from its generation"""
        foundOptimal = False
        self.count += 1

        if verbose:
            print("Generation", self.count)
        self.fits = [state.getValue() for state in self.currStates]
        if self.maxFit in self.fits:  # we have an optimal solution
            pos = self.fits.index(self.maxFit)
            bestOne = self.currStates[pos]
            foundOptimal = True
        else:
            bestLoc = self.fits.index(max(self.fits))
            bestOne = self.currStates[bestLoc]
            parentPool = self.selectParents(self.currStates, self.fits)
            self.currStates = self.mateParents(parentPool, self.crossPerc, self.mutePerc)
        if bestOne.getValue() > self.bestSoFarState.getValue():
            # Update the current state to the best of all generations
            self.bestSoFarState = bestOne
            self.bestSoFarValue = bestOne.getValue()

        if foundOptimal or self.count >= self.maxGenerations:
            if verbose:
                print("The optimal solution found in Genaration:{} \t {} \tScore {}".format(self.count, self.bestSoFarState, self.bestSoFarValue))
            return 'optimal'
        else:
            if verbose:
                print("Best of Genaration:{} \t {} \tScore {}".format(self.count, self.bestSoFarState, self.bestSoFarValue))
            return 'end generation'

    def _selectParents(self, states, fitnesses):
        """given a set of states, repeatedly select parents using roulette selection"""
        parents = []
        for i in range(len(states)):
            nextParentPos = self._rouletteSelect(fitnesses)
            parents.append(states[nextParentPos])
        return parents

    def _mateParents(self, parents, crossoverPerc, mutationPerc):
        """Given a set of parents, pair them up and cross them together to make
        new kids"""
        newPop = []
        for i in range(0, len(parents), 2):
            p1 = parents[i]
            p2 = parents[i + 1]
            doCross = random.random()
            if doCross < crossoverPerc:
                n1, n2 = self._crossover(p1, p2)
                newPop.append(n1)
                newPop.append(n2)
            else:
                newPop.append(p1.copyState())
                newPop.append(p2.copyState())
        for i in range(len(newPop)):
            nextOne = newPop[i]
            doMutate = random.random()
            if doMutate <= mutationPerc:
                newPop[i] = nextOne.makeRandomMove()
        return newPop


    def _crossover(self, oneState, otherState):
        """Single-point crossover"""
        crossPoint = random.randint(0, oneState.RULE_LEN)
        crossIndex = random.randint(0, oneState.RULE_LEN)
        if crossPoint == 0 or crossPoint == oneState.RULE_LEN:
            oneNewState = oneState.copyState()
            otherNewState = otherState.copyState()
            return oneNewState, otherNewState
        else:
            oneNewRuleString= oneState.ruleString[:crossIndex] + otherState.ruleString[crossIndex :]
            otherNewRuleString= otherState.ruleString[:crossIndex] + oneState.ruleString[crossIndex :]
            oneNewState = RulesetState(oneState.getEvalFunction(), otherState.getMaxValue, oneNewRuleString)
            otherNewState = RulesetState(otherState.getEvalFunction(), otherState.getMaxValue, otherNewRuleString)
            return oneNewState,otherNewState

    def printNeighbors(self, neighList, full=True):
        """Takes a list of neighbors and values, and prints them all out"""
        print("Neighbors:")
        for neigh in neighList:
            neigh.setPrintMode(full)
            print(neigh)

    def _rouletteSelect(self, valueList):
        """takes in a list giving the values for a set of entities.  It randomly
    selects one of the positions in the list by treating the values as a kind of
    probability distribution and sampling from that distribution.  Each entity gets
    a piece of a roulette wheel whose size is based on comparative value: high-value
    entities have the highest probability of being selected, but low-value entities have
    *some* probability of being selected."""
        totalValues = sum(valueList)
        pick = random.random() * totalValues
        s = 0
        for i in range(len(valueList)):
            s += valueList[i]
            if s >= pick:
                return i
        return len(valueList) - 1

    def alreadyIn(self, state, stateList):
        """Takes a state and a list of state, and determines whether the state
        already appears in the list of states"""
        for s in stateList:
            if state == s:
                return True
        return False
