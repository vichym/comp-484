"""  =================================================================
File: MacStateAdvisors.py

This file contains State classes and TaskAdvisor classes suitable for the grid
world.
 ==================================================================="""


# ==========================================================================================

class MacState(object):
    """This represents the state of a search in a Mac Map.  It does not
    represent the map, just the current location in the map, and the
    series of cells that have been traversed to get to this location.  That
    is represented in the pathToMe instance variable inherited from the parent
    class.  The cost is determined externally, by the task advisor.
    NOTE: for many search algorithms, we need to store the state object in a set, and to be able to find equivalent
    states that may have different costs, but fundamentally refer to the same place in the map.
    Thus any state class you create MUST implement the __eq__ and __hash__ methods, which are used by Python's set
    data type. These methods should be based on the information about the location in the map. For this
    state, that means the state number (node number) indices of the grid square this state represents."""

    def __init__(self, stateNumber, path=[], cost=0):
        """Given the state location number of the current state, and optional path
        and cost, initializes the state for the search"""
        if path is None:
            self.pathToMe = []
        else:
            self.pathToMe = path
        self.myCost = cost
        self.stateNumber = stateNumber


    def setPath(self, newPath):
        """This is a method that Dijkstra's needs."""
        self.pathToMe = newPath

    def getPath(self):
        """Access the value of the pathToMe instance variable"""
        return self.pathToMe

    def getCost(self):
        """Access the value of the myCost instance variable"""
        return self.myCost

    def getStateNumber(self):
        """Return the state number"""
        return self.stateNumber

    def __eq__(self, state):
        """Check if the input is the same type, and if it has the same stateNumber
        Overloads the == operator."""
        if type(state) is type(self):
            return state.stateNumber == self.stateNumber
        else:
            return False

    def __hash__(self):
        """Makes the state hashable by hashing a tuple of its state number (node number), so that it can be stored in
        a set or dictionary. Note that states that are == will produce the same hash value."""
        return hash(self.stateNumber)

    def __str__(self):
        """To print this object, print the state number (node number) in brackets, followed by the
        path and cost"""
        strng = "\n\t\t\tFinal Node: \t (" + str(self.stateNumber) + ")"
        strng += "\n\t\tPath to Node: \t" + str(self.pathToMe) + "\n\t\tCost to Here: \t" + str(self.myCost) +"\n"
        return strng


# ==========================================================================================
class AStarMacState(MacState):
    """This represents the state of a search in a map.  It does not
represent the maze, just the current location in the maze, and the
series of cells that have been traversed to get to this location.  That
is represented in the pathToMe instance variable inherited from the parent
class.  The cost is determined externally."""

    def __init__(self, stateNumber, path=None, costToHere=None, costToGoal=None):
        """Given the state number (node number), the current path, and the two costs (cost so far and heuristic
        cost to come, this creates a state/node for the search"""

        MacState.__init__(self, stateNumber, path, costToHere + costToGoal)
        self.costToHere = costToHere
        self.costToGoal = costToGoal
        self.myCost = self.costToHere + self.costToGoal

    def getCostToHere(self):
        """Return the cost so far"""
        return self.costToHere

    def getCostToGoal(self):
        """Return the heuristic estimate cost to the goal"""
        return self.costToGoal

    def __str__(self):
        """Create a string for printing that contains the Node number plus path and costs to here"""
        strng = "\n\t\t\tFinal Node: \t (" + str(self.stateNumber) + ")"
        strng += "\n\t\tPath to Node: \t" + str(self.pathToMe) + "\n\t\tCost to Here: \t" + str(self.costToHere)
        strng += "\n\t\tTotal Cost: \t" + str(self.myCost) +"\n"
        return strng


class MacTaskAdvisor(object):
    """This is the task advisor for the Mac task in general. it knows how to determine what a goal
    is, and how to work with the MacState, and how to generate neighbors in general. There will be
    subclasses of this class for each kind of search, because the details of costs for neighbors vary from
    one algorithm to the next."""

    def __init__(self, macGraph, startStateNumber, goalStateNumber):
        """Given a map, the starting and goal location number, this initializes the variables
        that hold details of the problem"""
        self.macGraph = macGraph
        self.goalStateNumber = goalStateNumber
        self.startState = self._setupInitialState(startStateNumber)

    def _setupInitialState(self, startStateNumber):
        """This creates and returns a proper start state for this particular
        class. In this case cost is the distance travelled so far, and that
        starts at whatever the starting position has in it."""
        return MacState(startStateNumber, [])

    def getStartState(self):
        """Returns the start state, in the proper form to be used by the search."""
        return self.startState


    def isGoal(self, state):
        """Given a state, check if it is a goal state.  It must have the same stateNumber
        as the goal"""
        if state.getStateNumber() == self.goalStateNumber:
            return True
        else:
            return False

    def generateNeighbors(self, state):
        """Given a state, determine all legal neighbor states."""
        neighs = self.macGraph.getNeighbors(state.getStateNumber())
        neighborStates = []
        for neighbor in neighs:
            neighborStates.append(self._buildNeighborState(state, neighbor[0], neighbor[1]))
        return neighborStates

    def _buildNeighborState(self, currState, newStateNumber, distance = 0):
        """Given the current state and the location of the neighbor, this builds
        a new state, computing the cost as appropriate for the class.
        This will be overridden by most subclasses!"""
        newPath = currState.getPath()[:]
        newPath.append(currState.getStateNumber())
        return MacState(newStateNumber, newPath)
# ==========================================================================================


class UCSMacAdvisor(MacTaskAdvisor):
    """This class is a subclass of the MacTaskAdvisor. It implements the cost calculations
    used for UCS search, and is intended to be paired with a BestFirstSearchSolver."""

    def _setupInitialState(self, stateNumber):
        """This creates and returns a proper start state for this particular
        class. In this case cost is the distance travelled so far"""
        return MacState(stateNumber, [])

    def _buildNeighborState(self, currState, newStateNumber, distance):
        """Given the current state and the location of the neighbor, this builds
        a new state, computing the cost as appropriate for the class.
        In this case, the cost is the cost in currState plus the cost in the neighbor."""
        newPath = currState.getPath()[:]
        newPath.append(currState.getStateNumber())
        newCost = currState.getCost() + distance
        return MacState(newStateNumber, newPath, newCost)


# ==========================================================================================




class AStarMacAdvisor(MacTaskAdvisor):
    """This class is a subclass of the MacTaskAdvisor. It implements the cost calculations
    used for A* search, using the AStarState, which maintains both g and h costs. It is intended to
    be paired with a BestFirstSearchSolver."""

    def _setupInitialState(self, stateNumber):
        """This creates and returns a proper start state for this particular
        class. In this case, it computes all the two values, g, and h:
        g = the cost of the starting cell
        h = the heuristic distance to goal
        The f cost is automatically computed by the AStarMacState (f = g + h)
        """
        g = 0 # initially, there is 0 travelled distance
        h = self.macGraph.heuristicDist(stateNumber, self.goalStateNumber)
        return AStarMacState(stateNumber, [], g, h)

    def _buildNeighborState(self, currState, newStateNumber, distance):
        """Given the current state and the location of the neighbor, this builds
        a new state, computing the cost as appropriate for the class.
        In this case, we need to update both g and h costs for the new state:
        new g = old g + new cell's weight,
        new h = distance to goal of new cell"""
        newPath = currState.getPath()[:]
        newPath.append(currState.getStateNumber())
        newG = currState.getCostToHere() + distance
        newH = self.macGraph.heuristicDist(newStateNumber, self.goalStateNumber)
        return AStarMacState(newStateNumber, newPath, newG, newH)

#
