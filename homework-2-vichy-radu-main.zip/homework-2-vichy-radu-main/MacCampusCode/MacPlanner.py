"""  =================================================================
File: MazeLocalization.py

This file contains code, including a Tkinter class, that implements the
GUI for this problem.  This must be run in Python 3!
 ==================================================================="""

#


from MacSearchSolver import BestFirstSearchSolver
from MacStateAdvisors import  AStarMacAdvisor, UCSMacAdvisor
from LoadGraphs import loadMacGraph

class MacMap():
    def __init__(self):
        self.graph = self._loadGraph()

    def _loadGraph(self):
        return loadMacGraph()

    def _readSearchAlgorithmInput(self):
        print("Please select search Algorithm: \n Type: '1' for UCS \n Type: '2' for A* \n Type: '0' to Stop")
        algorithm = input("Select search: ")
        return algorithm

    def _readStateInput(self):
        start , goal = 0, 0
        while not (0 < start <= 94  and 0 <  goal  <= 94 and start != goal):
            start = int(input("Start Location number : "))
            goal = int(input("End Location number : "))
        self.startStateNumber = start
        self.goalStateNumber = goal

    def runSearch(self):
        self.currentSearcher.initSearch()
        result = self.currentSearcher.searchLoop(True)


    def run(self):
        """This starts it all up.  Sets up the MazeGUI, and its widgets, and makes it go"""

        # User select search algorithm
        algorithm = self._readSearchAlgorithmInput()

        while algorithm != "0":
            # validate search algorithm options
            if algorithm != '2' and algorithm != '1':
                print("Please select a valid input !")
            else:
                # User input starting and ending location number
                self._readStateInput()
                if algorithm == '2':
                    taskAdvisor = AStarMacAdvisor(self.graph, self.startStateNumber, self.goalStateNumber)
                    self.currentSearcher = BestFirstSearchSolver(taskAdvisor)
                else:
                    taskAdvisor = UCSMacAdvisor(self.graph, self.startStateNumber, self.goalStateNumber)
                    self.currentSearcher = BestFirstSearchSolver(taskAdvisor)
                self.runSearch()

            algorithm = self._readSearchAlgorithmInput()

if __name__ == "__main__":
    MacMap().run()
