
import matplotlib.pyplot as plt

from sklearn import datasets
from sklearn import tree
from sklearn.metrics import confusion_matrix, plot_confusion_matrix, classification_report
from sklearn.model_selection import train_test_split, KFold, cross_val_score

if __name__ == '__main__':
    # Load two sample datasets
    iris = datasets.load_iris()
    print(len(iris.data))
    irisTree = tree.DecisionTreeClassifier()
    irisTree.fit(iris.data, iris.target)

    targValue = iris.target[3]
    predVal = irisTree.predict(iris.data[3:4])
    print(targValue, "should equal", predVal)


    digits = datasets.load_digits()
    print(len(digits.data))
    digitsTree = tree.DecisionTreeClassifier()
    digitsTree.fit(digits.data, digits.target)

    digitsTree2 = tree.DecisionTreeClassifier()
    digitsTrainData, digitsTestData, digitsTrainTarget, digitsTestTarget = train_test_split(digits.data, digits.target, test_size=.1)
    digitsTree2.fit(digitsTrainData, digitsTrainTarget)

    # print(iris.data)
    # print(iris.target)
    print(digits.data[0])
    print(digits.target[0])
    print(iris.data[0:10])
    print(iris.target[0:10])

    print(digits.images[0])
    print(digits.target[0])
    print(digits.images[3])
    print(digits.target[3])

    print("==============================")
    print("IRIS DATA")
    predicted = irisTree.predict(iris.data)
    tree.plot_tree(irisTree)
    print("Classification report for classifier", irisTree)
    print(classification_report(iris.target, predicted))
    plot_confusion_matrix(irisTree, iris.data, iris.target)

    plt.show()

    print("==============================")
    print("DIGITS DATA")

    #display 4 of the digits as images, along with some other info
    _, axes = plt.subplots(2, 4)
    images_and_labels = list(zip(digits.images, digits.target))
    for ax, (image, label) in zip(axes[0, :], images_and_labels[:4]):
        ax.set_axis_off()
        ax.imshow(image, cmap=plt.cm.gray_r, interpolation='nearest')
        ax.set_title('Training: %i' % label)

    predicted = digitsTree.predict(digits.data)
    plt.figure()
    tree.plot_tree(digitsTree)
    print("Classification report for classifier", digitsTree)
    print(classification_report(digits.target, predicted))
    plot_confusion_matrix(digitsTree, digits.data, digits.target)

    predicted2 = digitsTree2.predict(digitsTestData)
    plt.figure()
    tree.plot_tree(digitsTree2)
    print("Classification report for classifier", digitsTree2)
    print(classification_report(digitsTestTarget, predicted2))
    plot_confusion_matrix(digitsTree2, digitsTestData, digitsTestTarget)

    plt.show()

    decisionTree3 = tree.DecisionTreeClassifier()
    print(cross_val_score(decisionTree3, digits.data, digits.target, cv=KFold(n_splits=5), n_jobs=-1))


