#
#
# from sklearn.datasets import load_svmlight_file
# examples, targets = load_svmlight_file("/Users/susan/Courses/Comp484/Homework/Wall-Following_Robot_Navigation/sensorReadings24.libsvm")
# print(examples.shape, targets.shape)

import os
# import arff
from scipy.io import arff
from io import StringIO

import numpy as np
import urllib.request


def readArffs(folder):
    """Goes through a folder and reads in and prints every ARFF file in the folder."""
    files = os.listdir(folder)
    for file in files:
        print("=================================")
        if file.endswith("arff") or file.endswith("ARFF"):
            pathAndFile= folder + '/' + file
            data = readArff(pathAndFile)
            if data is not None:
                print(data.shape)
    return data


def readArff(file):
    """Given a filename, it reads in the data and returns it in a format that scikit-learn can use."""
    if not (file.endswith("arff") or file.endswith("ARFF")):
        print("Not an arff file")
        return None

    print("Reading file", file)
    try:
        dataset, metadata = arff.loadarff(open(file, 'r'))
    except Exception as e:
        print("Couldn't load dataset")
        print(e)
        return None

    print(type(dataset))
    return dataset


def readCSV(file):
    """Given a filename that is a CSV file, reads in the data."""
    fil = open(file, 'r')
    dataset = np.loadtxt(fil, delimiter=",")
    print(dataset.shape)
    return dataset


def readURL(url):
    """Given a URL as a string, this reads the dataset from that url"""
    raw_data = urllib.request.urlopen(url)
    dataset = np.loadtxt(raw_data, delimiter=",")
    print(dataset.shape)
    return dataset



# dataset = readCSV("Datasets-New/Arrhythmia/adult+stretch.data")
# print(dataset)



# readURL("https://archive.ics.uci.edu/ml/machine-learning-databases/annealing/anneal.data")
# readArffs("Datasets-ARFF")
# readArffs("datasets-UCI/UCI")
# print()
# print()
