"""
This file imports the Decision Tree  and Corpus classes from other files, and creates a corpus from a given file.
It also creates a Decision Tree object from that file. The code cannot actually build the tree, as its ID3 algorithm
is missing, but it can manipulate the dataset and check for consistency, and compute the gain.
THis file contains a couple of 'helper' printing functions, and an example showing how to read in a dataset,
and use the DTree object to compute gains and divide the dataset."""


from corpus import Corpus
from DTree import DecisionTree


def printInstances(instances):
    """Print instances"""
    for inst in instances:
        print(inst)


def printGains(attribList, instList, decisTree):
    """Given a list of attributes of interest, and a list
    of Instances, and a decision tree, uses the decision tree's gain
    calculator to determine the gain for each listed attribute, and
    prints them."""
    formStr = "Gain for attribute {0:15s} = {1:6.3f}"
    for attr in attribList:
        g = decisTree.gain(attr, instList)
        currStr = formStr.format(attr, g)
        print(currStr)


# =============================================================================================

# First, read in the dataset and build the dTree object (which can't actually build the tree,
# but does have functions for computing gain and splitting up datasets).

corp = Corpus("PythonDatasets/dog2.dat")
dTree = DecisionTree(corp)
probs = dTree.genEntropyProbs(dTree.instances)
print("Overall P(Good?) =", probs)
totalEntropy = dTree.entropy(probs)
print("Overall entropy:", totalEntropy)


# Separate the whole dataset by color
colorValues = corp.getAttributeValues("Color")
e1 = dTree.getSamplesWithValue("Color", "black", dTree.instances)
e2 = dTree.getSamplesWithValue("Color", "white", dTree.instances)
e3 = dTree.getSamplesWithValue("Color", "gray", dTree.instances)
e4 = dTree.getSamplesWithValue("Color", "brown", dTree.instances)
# Compute entropy for e1
probs1 = dTree.genEntropyProbs(e1)
e1Entropy = dTree.entropy(probs1)
# Compute entropy for e2
probs2 = dTree.genEntropyProbs(e2)
e2Entropy = dTree.entropy(probs2)
# Compute entropy for e3
probs3 = dTree.genEntropyProbs(e3)
e3Entropy = dTree.entropy(probs3)
# Compute entropy for e1
probs4 = dTree.genEntropyProbs(e4)
e4Entropy = dTree.entropy(probs4)


# Compute remainder
remaind = (0.25 * e1Entropy) + (0.25 * e2Entropy) + (0.25 * e3Entropy) + (0.25 * e4Entropy)
print("Remainder:", remaind)
colorGain = totalEntropy - remaind
print("Gain for color =", colorGain)

shortcutGain = dTree.gain('Color', dTree.instances)
print("Shortcut =", shortcutGain)

atts = dTree.dataset.getAttributes()
for att in atts:
    print(att + " Gain =", dTree.gain(att, dTree.instances))
print("===============")
smallDogs = dTree.getSamplesWithValue('Size', 'small', dTree.instances)
medDogs = dTree.getSamplesWithValue('Size', 'medium', dTree.instances)
bigDogs = dTree.getSamplesWithValue('Size', 'big', dTree.instances)

for size in ["small", "medium", "big"]:
    for att in atts:
        dogs = dTree.getSamplesWithValue('Size', size, dTree.instances)
        print(size, att + " Gain =", dTree.gain(att, dogs))

for personality in ["hyper", "nice", "placid", "mean"]:
    for att in atts:
        dogs = dTree.getSamplesWithValue('Size', "medium", dTree.getSamplesWithValue("Personality", personality, dTree.instances))
        print("medium", personality, att + " Gain =", dTree.gain(att, dogs))