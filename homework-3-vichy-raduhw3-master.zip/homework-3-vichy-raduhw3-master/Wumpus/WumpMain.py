

from players import UserPlayer
from naiveBayesPlayer import NaiveBayesPlayer
from wumpWorld import WumpWorld

testMode = True
def wumpusGame(MakePlayer):
    rows = 8
    cols = 8
    world = WumpWorld(rows, cols)
    # world.wumpMap.printGrid()
    pr, pc = world.getHeroLoc()
    userP = MakePlayer((pr, pc), (rows, cols))
    while True:
        senses = world.heroSenses()
        act = userP.nextAction(senses)
        if act == 'q':
            break
        else:
            if act[0] == 'move':  # moving
                result, newLoc = world.moveHero(act[1])
            else:
                result = world.shootArrow(act[1])

            if not world.isWumpusAlive():
                print("You killed the Wumpus!")
                print("CONGRATULATIONS!")
                # break
                return True
            elif not world.isHeroAlive():
                print("Result =", result)
                if result == 'pit':
                    print("You fell in a pit and died!")
                    # break
                    if testMode:
                        userP.knowledge.printGrid()
                    return False
                elif result == 'wumpus':
                    print("You met the Wumpus! It ate you.")
                    # break
                    if testMode:
                        userP.knowledge.printGrid()
                    return False
                else:
                    print("wumpusGame: should never get here, player dead and no cause.")
            else:
                userP.playerMoved(result, newLoc)
    print("Game over...")
    return True



if __name__ == "__main__":
    # wumpusGame(UserPlayer)

    report = {"win":0, "lose":0}
    for _ in range(500):
        result = wumpusGame(NaiveBayesPlayer)
        if result:
            report["win"] += 1
        else:
            report["lose"] += 1
    print(report)
