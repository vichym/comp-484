# homework-3
Code for Homework 3, Wumpus, Naive Bayes, and Bayesian Networks

The Wumpus folder contains updated code for the Hunt the Wumpus program, including code to support a computer player who uses Naive Bayes to help determine where to go.

The BayesNet folder contains code to implement a Bayesian network, which may be read from a file. The code for estimating probabilities is incomplete and students will complete it

# Report - Hunt the Wumpus

Our hero does a pretty good job at playing this game, with a success rate of 95 percent. We ran the simulation 40 times and 38 times the hero successfully killed the wumpus. In one case the hero walked into the wumpus and one time it fell into a pit. The hero usually shoots when it finds blood into two cells that are perpendicular to each other and have another neighbor with blood (This is an L shape of blood cells)

There were cases when the hero was placed right next to the wumpus and it walked right into it. This is normal behaviour since the hero doesn't have much information to take a safe decision. The wumpus walks into bats easily and in the majority of cases it explores most of the baord before finding the wumpus. 

