from bayesNetDef import *

# ================================================================
# The code below builds a Bayesian Network as specified in the
# file


network = BayesNet()

# filename = input("Enter filename to read from: ")
filename = "openDoor.txt"
network.readBayesNet(filename)

# Call below computes conjunctive or conditional probability distributions
# prob distribution
#
# while True:
#     yorn = input("Shall we compute some probabilities? ")
#     if yorn.lower() in ['n', 'no', 'q', 'quit', 'e', 'exit']:
#         break
#     network.askProbs()

samples = 30000

rejectionSampling0 = network.rejectionSampling("RoommateInHouse", {"OpenDoor":'True'}, samples)
rejectionSampling1 = network.rejectionSampling("RoommateInHouse", {"OpenDoor":'True', 'CarInGarage':"True"}, samples)
rejectionSampling2 = network.rejectionSampling("OpenDoor", {"DamagedDoor":'True'}, samples)
rejectionSampling3 = network.rejectionSampling("RoommateInHouse", {"OpenDoor":'True', 'CarInGarage':"False"}, samples)

print(rejectionSampling0)
print(rejectionSampling1)
print(rejectionSampling2)
print(rejectionSampling3)

likelyHoodWeightingSampling0 = network.rejectionSampling("RoommateInHouse", {"OpenDoor": 'True'}, samples)
likelyHoodWeightingSampling1 = network.rejectionSampling("RoommateInHouse", {"OpenDoor": 'True', 'CarInGarage': "True"},
                                                         samples)
likelyHoodWeightingSampling2 = network.likelihoodWeighting("OpenDoor", {"DamagedDoor": 'True'}, samples)
likelyHoodWeightingSampling3 = network.rejectionSampling("RoommateInHouse",
                                                         {"OpenDoor": 'True', 'CarInGarage': "False"}, samples)

print(likelyHoodWeightingSampling0)
print(likelyHoodWeightingSampling1)
print(likelyHoodWeightingSampling2)
print(likelyHoodWeightingSampling3)

# roommateInHouseSamps1 = [s for s in priorSamps if s['OpenDoor'] == 'True']
# roommateInHouseSamps2 = [s for s in priorSamps if s['OpenDoor'] == 'True' and s['CarInGarage'] == 'True']
# roommateInHouseSamps3 = [s for s in priorSamps if s["DamagedDoor"] == 'True']
# roommateInHouseSamps4 = [s for s in priorSamps if s['OpenDoor'] == 'True' and s['CarInGarage'] == 'False']
# print("Number of cases " + str(len(roommateInHouseSamps1)))
# print("Probability that the roommate is in the house 1 =", len(roommateInHouseSamps1) / samples)
# print("Number of cases " + str(len(roommateInHouseSamps2)))
# print("Probability that the roommate is in the house 2 =", len(roommateInHouseSamps2) / samples)
# print("Number of cases " + str(len(roommateInHouseSamps3)))
# print("Probability that the roommate is in the house 3 =", len(roommateInHouseSamps3) / samples)
# print("Number of cases " + str(len(roommateInHouseSamps4)))
# print("Probability that the roommate is in the house 4 =", len(roommateInHouseSamps4) / samples)
