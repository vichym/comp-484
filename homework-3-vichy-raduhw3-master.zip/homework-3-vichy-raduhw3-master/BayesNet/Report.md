                                                                           

#     Homework 3 Report
       # Report - Hunt the Wumpus

Our hero does a pretty good job at playing this game, with a success rate of 95 percent. We ran the simulation 500 times 
and {'win': 461, 'lose': 39} which is 92% success rate. Run the main function in WumpusMain.py to see the test. Most of 
lose cases, the hero walked into the pit while others remaining times it walked into the wumpus. 
Usually in these cases, the hero was initially placed right next to the wumpus or the pit and it walked right into it. This is normal 
behaviour since the hero doesn't have much information at the beginning of the game to take a safe decision. 
The wumpus walks into bats easily and in the majority of cases it explores most of the baord before finding the wumpus. 
The hero usually shoots when it finds blood into two cells that are perpendicular to each other and have another neighbor
with blood (This is an L shape of blood cells).


        # Report - BayesNet
For rejection sample, in order to get probabilities that resemble the real ones we needed to run up to 200 000 simulations.
With this number of samples, we get a small probability for the fourth case when we need to find the probability that RoommateInHouse given that the door is open and the car is not in garage. With a number of samples bellow this, we would get a probability of 0 for this event. 

On the other hand, likelihood 
weighting sampling requires a higher number of samples (250 000) in order to get a small probability for the fourth case when we need 
to find the probability that RoommateInHouse is true given that the doorIsOpen is true and the carInGarage is false. However, likelihood weighting requires less samples to find probabilities that are close enough for other scenarios (e.g prob that the roommate is in the house given that the door is open)




