# Homework 1
Starter code files for Homework 1

This contains a fresh copy of basicBot.py and testRobot.py, which you may not need, if you have a working one on your robot.

In addition, this contains starterBraitenberg.nlogo, which is a complete NetLogo model that creates environments for Braitenberg Vehicles. You will implement different basic Braitenberg vehicle code.
