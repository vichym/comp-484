from Tkinter import *

root = Tk()

scrollbar1 = Scrollbar(root)
scrollbar1.grid(row = 1, column = 50, rowspan=49,sticky='NS')
scrollbar2 = Scrollbar(root, orient=HORIZONTAL)
scrollbar2.grid(row=50, column=1, columnspan=49,sticky='EW')

myFrame = Frame(root, bg='red')
myFrame.grid(row=1, column=1)
listbox = Listbox(myFrame)
listbox.grid(row=1, column = 1)

for i in range(100):
    listbox.insert(END, '*' * i)

# attach listbox to scrollbar
myFrame.config(yscrollcommand=scrollbar1.set, xscrollcommand=scrollbar2.set)
scrollbar1.config(command=listbox.yview)
scrollbar2.config(command=listbox.xview)

mainloop()