# HuntTheWumpus
We’re going to use a different, simpler version of the Wumpus World game to explore basic probability ideas. I’ve implemented a simpler version in Python with a text interface. In my implementation, you are still supposed to find and kill the wumpus, and pits are marked with slime and the wumpus with bloodstains in the same way as the game version. There are bats that act similar to the game version: the first time you meet a bat it ignores you. If you re-enter a room with a bat, it may move you to a random room, including where a pit or the wumpus are. However, for simplicity the rooms are laid out in a grid and each room is adjacent to the rooms above, below, to the right, and to the left of it. The maze wraps around from right to left and bottom to top.

Locations in the grid dungeon will be given by an ordered pair: (row, col) giving the horizontal and vertical position, with (0, 0) in the upper left corner. The player starts in a random location.
					
